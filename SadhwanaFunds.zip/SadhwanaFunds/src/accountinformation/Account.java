package accountinformation;

public class Account {

 private String Name, DOB, FName;
 private Integer AccNo, Balence;
 public Account(Integer AccNo, String Name,String DOB,String FName,Integer Balence){
	 this.AccNo = AccNo;
	 this.Name = Name;
	 this.FName= FName;
	 this.DOB=DOB;
	 this.Balence=Balence;
 }
public Account() {
	// TODO Auto-generated constructor stub
}
public void setAccNo(Integer AccNo)
 {
	 this.AccNo = AccNo;
 }
 public void setBalence(Integer Balence)
 {
	 this.Balence = Balence;
 }
 public void setName(String Name)
 {
	 this.Name = Name;
 }
 public void setFName(String FName)
 {
	 this.FName = FName;
 }
 public void setDOB(String DOB)
 {
	 this.DOB = DOB;
 }
 public Integer getAccNo()
 {
	 return this.AccNo;
 }
 public String getName()
 {
	 return this.Name;
 }
 public String getFName()
 {
	 return this.FName;
 }
 public String getDOB()
 {
	 return this.DOB;
 }
 public Integer getBalence()
 {
	 return Balence;
 }
 @Override
 public String toString()
 {
	 return "Account Details:\n Account Number : "  +getAccNo()+"\tCustomer Name : "+getName()+"\tFather's Name : "+getFName()+"\t Date Of Birth : "+getDOB()+"\t Final Balence : "+getBalence();
 }
}