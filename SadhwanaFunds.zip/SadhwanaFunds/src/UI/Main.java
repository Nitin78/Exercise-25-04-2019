package UI;

import java.util.Scanner;

import CalculationService.ServiceConnection;
import accountinformation.Account;
import databseconnection.daoConnection;

public class Main {
	private int accno;
	int amt;
	static String name, Fname, dob;
	static Scanner sc =new Scanner(System.in);
	static Account aa = new Account();
	
		// TODO Auto-generated method stub
		static void createacc() {
			Main m = new Main();
		System.out.println("Enter the Account Number");
		aa.setAccNo(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter the Customer Name");
		aa.setName(sc.nextLine());
		System.out.println("Enter the Father's Name");
		aa.setFName(sc.nextLine());
		System.out.println("Enter Date of Birth of Customer");
		aa.setDOB(sc.nextLine());
		System.out.println("Enter the Basic Amount");
		aa.setBalence(sc.nextInt());
		}
		static void clearbal() {
			System.out.println("Enter the Account Number");
			int aaa=sc.nextInt();
			aa.setAccNo(aaa);
		}
		public static void main(String[] args) {
			char ch='y';
			do {
			System.out.println("1. For Create Account\n2. For Check Balence");
			int choice=sc.nextInt();
			ServiceConnection ss = new ServiceConnection();
			ss.Connectionlink();
			switch(choice) {
				case 1:
					createacc();
					ss.insertdetails(aa);
				break;
				case 2:
					clearbal();
					ss.getBalence(aa);
				break;
				default:
				System.out.println("You have entered wrong deatils..");
			}
			}while(ch=='y');
			
			
		}
	
}
