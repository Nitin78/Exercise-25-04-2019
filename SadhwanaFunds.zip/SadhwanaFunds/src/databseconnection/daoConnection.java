package databseconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import UI.Main;
import accountinformation.Account;

public class daoConnection {
	Connection dbCon;
	PreparedStatement theStatement;
	PreparedStatement theStatemen;
	Main m = new Main();
	Account a=new Account();
	public void Connectionlink()
	{
		try {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Make the connection
			this.dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/AccountInformation?serverTimezone=UTC", "root", "");
	}catch (ClassNotFoundException | SQLException e) {
		System.out.println("Some issues : " + e);
	}
	}

	public void insertdetails(Account a) {
		System.out.println("Hello Id of insertDetails : "+a.getAccNo());
		String query = "insert into accountdetails values(?,?,?,?)";
		String query1 = "insert into transaction values(?,?)";
		try {
			this.theStatement =this.dbCon.prepareStatement(query);
			this.theStatemen =this.dbCon.prepareStatement(query1);
			this.theStatement.setInt(1, a.getAccNo());
			this.theStatement.setString(2, a.getName());
			this.theStatement.setString(3, a.getFName());
			this.theStatement.setString(4, a.getDOB());
			this.theStatemen.setInt(1, a.getAccNo());
			this.theStatemen.setInt(2, a.getBalence());
	
			if(this.theStatement.executeUpdate() > 0) {
				System.out.println("User details updated...");
			}
			if(this.theStatemen.executeUpdate() > 0) {
				System.out.println("Transaction table updated...");
			}
			
		} catch (SQLException e) {
			System.out.println("Some issues in insert details: " + e);
		}
	}
	public void getBalence(Account a)
	{	
		
		String fetchQry = "SELECT accountdetails.accno,name,balence FROM accountdetails,transaction WHERE accountdetails.accno=transaction.accno and transaction.accno=?";
		try {
			this.theStatement =this.dbCon.prepareStatement(fetchQry);
			this.theStatement.setInt(1, a.getAccNo());
			//this.theStatement.setInt(2, a.getAccNo());
			ResultSet theResultSet = this.theStatement.executeQuery();
			while(theResultSet.next())
			{
				System.out.println("Account No : "+theResultSet.getInt("accno"));
				System.out.println("Customer Name : "+theResultSet.getString("name"));
				System.out.println("Clear Balence : "+theResultSet.getInt("balence"));
			}
		}catch(SQLException e) {
			System.out.println("Some issue in Get Balence" +e);
		}
}
}
