package databseconnection;

public interface daoInterface {
abstract void insertdetails();
}
