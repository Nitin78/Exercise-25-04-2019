package CalculationService;

import accountinformation.Account;
import databseconnection.daoConnection;

public class ServiceConnection{
	daoConnection dao = new daoConnection();
	Account a =new Account();
	public void Connectionlink()
	{
		dao.Connectionlink();
	}
	public void insertdetails(Account aa) {
		// TODO Auto-generated method stub
		dao.insertdetails(aa);
	}
	public void getBalence(Account aa)
	{
		dao.getBalence(aa);
	}
}
