package CalculationService;

import accountinformation.Account;

public interface ServiceConnectionInterface {
	void Display();
	void Deposit();
	void WithDraw();
	void Transfer();
	void CreateAccount(Account a);
}
