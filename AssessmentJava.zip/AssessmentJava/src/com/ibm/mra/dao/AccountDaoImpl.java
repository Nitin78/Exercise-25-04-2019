package com.ibm.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.ibm.mra.beans.Account;

public class AccountDaoImpl {
	
	private Map<String,Account> map=new HashMap<String,Account>();
	
	public void rechargeAccount(Account s) {
		// TODO Auto-generated method stub
		map.put("9010210131",new Account("Vaishali", 200));
		map.put("7830260919",new Account("Nitin", 100) );
	}
	//public void recharge(Account s) {
//		// TODO Auto-generated method stub
//		if(map.get(key).equals(s.ge))
//		{
//		map.put("",new Account("Vaishali", 200));
//		}
//	}

	public Map<String,Account>getAccountDetails()
	{
		return map;
	}
	

	
	
}
