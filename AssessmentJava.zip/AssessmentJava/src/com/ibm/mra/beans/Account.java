package com.ibm.mra.beans;

public class Account {
	//private String mobileNo;
	private String customerName;
	private double rechargeAmount;
	public Account(String customerName, double rechargeAmount){
		// this.mobileNo = mobileNo;
		 this.customerName=customerName;
		 this.rechargeAmount=rechargeAmount;
	 }
	public Account() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * public void setMobileNo(String mobileNo) { this.mobileNo = mobileNo; }
	 */
	 public void setName(String customerName)
	 {
		 this.customerName = customerName;
	 }
	 public void setAmount(double rechargeAmount)
	 {
		 this.rechargeAmount = rechargeAmount;
	 }
//	 public String getMobileNo()
//	 {
//		 return this.mobileNo;
//	 }
	 public String getName()
	 {
		 return customerName;
	 }
	 public double getrechargeAmount()
	 {
		 return rechargeAmount;
	 }
	 @Override
	 public String toString()
	 {
		 return "Account Name :  "+getName()+" Balence : "+getrechargeAmount();
	 }
	// getter, setter & constructor
	
}
