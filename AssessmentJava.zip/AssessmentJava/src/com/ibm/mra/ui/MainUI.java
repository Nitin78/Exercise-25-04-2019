package com.ibm.mra.ui;

import java.util.Scanner;

import com.ibm.mra.beans.Account;
import com.ibm.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan= new Scanner(System.in);
		Account s = new Account();
		AccountServiceImpl service=new AccountServiceImpl();
		  //service.getPolicy(s);
		  service.rechargeAccount(s);
		  System.out.println(service.getAccountDetails());
	}

}
