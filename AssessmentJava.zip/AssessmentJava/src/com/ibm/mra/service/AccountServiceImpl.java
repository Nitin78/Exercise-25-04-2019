package com.ibm.mra.service;

import java.util.Map;

import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.AccountDaoImpl;

public class AccountServiceImpl {

	AccountDaoImpl d=new AccountDaoImpl();
	public void rechargeAccount(Account s) {
	d.rechargeAccount(s);
	}
	public Map<String,Account> getAccountDetails(){
		return d.getAccountDetails();
	}
	public void recharge(Account s) {
		d.rechargeAccount(s);
	}
}
